# المصادر: الـ 100 مستودع اللي اتحللوا

اتقروا يوم 2026-11-11 عن طريق `gh api` (الـ README و1-3 ملفات من أهم ملفات كل مستودع)، ومن غير clone. التقارير الكاملة بالإنجليزي في مجلد `research/` جوه مجلد الشغل «خطابة 2» (batch_01 لحد batch_10).

الصلة: 3 = اتاخد منه قواعد أساسية، 2 = مفيد في مجال واحد، 1 = حاجة صغيرة أو مجرد فهرس، 0 = مالوش لازمة.

| # | المستودع | الصلة | هو إيه |
|---|---|---|---|
| 1 | [morluto/rea](https://github.com/morluto/rea) | 1 | Local MCP + CLI for reverse engineering binaries, Electron/JS apps and web bundles; every result carries Evidence plus stated limitations (README, MCP |
| 2 | [affaan-m/ECC](https://github.com/affaan-m/ECC) | 3 | Large harness pack: 100+ skills/rules/hooks for Claude Code and other agents (`.agents/skills/*`) |
| 3 | [deepseek-ai/deepseek-harness](https://github.com/deepseek-ai/deepseek-harness) | 3 | DeepSeek's open-source plugin-architecture agent harness (Cordis); its `.agents/skills/` hold engineering rules (README, AGENTS.md) |
| 4 | [NousResearch/hermes-agent](https://github.com/NousResearch/hermes-agent) | 3 | Self-improving agent with agent-curated memory, FTS5 cross-session search, autonomous skill creation, subagent delegation (README) |
| 5 | [anthropics/skills](https://github.com/anthropics/skills) | 3 | Anthropic's reference skill collection plus the Agent Skills spec and template (README) |
| 6 | [DietrichGebert/ponytail](https://github.com/DietrichGebert/ponytail) | 3 | "Lazy senior dev" rules for agents, benchmarked: -53% code, -45% tokens, and 98% of risky logic shipped with tests vs 68% without (README, 39 tasks, 5 |
| 7 | [f/prompts.chat](https://github.com/f/prompts.chat) | 2 | Largest open prompt library (143k stars claimed), now a Next.js app with a prompt builder package and agent plugins (README, `packages/prompts.chat/sr |
| 8 | [langchain-ai/langchain](https://github.com/langchain-ai/langchain) | 1 | Python agent framework monorepo (core/langchain_v1/partners) |
| 9 | [nextlevelbuilder/ui-ux-pro-max-skill](https://github.com/nextlevelbuilder/ui-ux-pro-max-skill) | 2 | Design-intelligence skill: searchable CSVs (80 styles, 192 palettes, 74 font pairings, 120 UX rules, 17 GSAP presets) queried by a script (`.claude/sk |
| 10 | [Graphify-Labs/graphify](https://github.com/Graphify-Labs/graphify) | 2 | Turns a folder (code, docs, papers, images, video) into a persistent knowledge graph with community detection, GRAPH_REPORT.md, a wiki and an MCP serv |
| 11 | [microsoft/generative-ai-for-beginners](https://github.com/microsoft/generative-ai-for-beginners) | 1 | Microsoft course on building with LLMs (21 lessons); the useful parts are chapters 04/05 (prompt engineering) and one Copilot skill file |
| 12 | [browser-use/browser-use](https://github.com/browser-use/browser-use) | 2 | Browser agent (v1.0) where the model writes Python in a persistent REPL with CDP helpers instead of picking one action per step |
| 13 | [stablyai/orca](https://github.com/stablyai/orca) | 2 | Electron IDE for running parallel coding agents; AGENTS.md is a compact rules file with strong ratchets |
| 14 | [thedotmack/claude-mem](https://github.com/thedotmack/claude-mem) | 3 | Claude Code plugin: hooks capture tool activity, a second "observer" agent writes observations to SQLite plus Chroma, and the next session starts with |
| 15 | [addyosmani/agent-skills](https://github.com/addyosmani/agent-skills) | 3 | Library of 20+ engineering SKILL.md files with personas, evals and orchestration rules |
| 16 | [paperclipai/paperclip](https://github.com/paperclipai/paperclip) | 2 | Multi-agent "company" orchestration platform; .agents/skills holds many maintenance skills |
| 17 | [Leonxlnx/taste-skill](https://github.com/Leonxlnx/taste-skill) | 2 | Anti-slop frontend design skill (v2.5) with a Stop hook that runs a gate script in a real browser |
| 18 | [Panniantong/Agent-Reach](https://github.com/Panniantong/Agent-Reach) | 1 | CLI plus skill giving agents read-only access to social/video/search platforms (Xiaohongshu, Bilibili, X, Reddit, YouTube subtitles) |
| 19 | [google-gemini/gemini-cli](https://github.com/google-gemini/gemini-cli) | 1 | Google's terminal agent; GEMINI.md and .gemini/skills show how it is developed |
| 20 | [nexu-io/open-design](https://github.com/nexu-io/open-design) | 3 | Open-source design agent composing layered system prompts (discovery, critique, media contract) for decks, prototypes, image/video/audio |
| 21 | [pbakaus/impeccable](https://github.com/pbakaus/impeccable) | 2 | Design skill for coding agents: `/impeccable <command> <target>` with sub-commands (critique, audit, polish, bolder, quieter, animate), a 62-rule dete |
| 22 | [tt-a1i/archify](https://github.com/tt-a1i/archify) | 2 | Skill that turns requirements, Mermaid or repo evidence into validated standalone interactive HTML diagrams and one-page explainers, with a CLI `final |
| 23 | [infiniflow/ragflow](https://github.com/infiniflow/ragflow) | 1 | Open-source RAG engine: template-based chunking, DeepDoc layout and OCR parsing, agentic retrieval with Low/Medium/High/Ultra thinking modes, and grou |
| 24 | [Egonex-AI/Understand-Anything](https://github.com/Egonex-AI/Understand-Anything) | 3 | Claude Code plugin that builds a knowledge graph of a codebase or docs with a multi-agent pipeline (project-scanner, file-analyzer, architecture-analy |
| 25 | [heygen-com/hyperframes](https://github.com/heygen-com/hyperframes) | 3 | HTML-to-deterministic-MP4 framework with agent skills (hyperframes, cli, registry, media-use, motion-doctrine, seam-craft, captions-overlay, and other |
| 26 | [shareAI-lab/learn-claude-code](https://github.com/shareAI-lab/learn-claude-code) | 3 | Twelve-step course (s01-s12) on building an agent harness: loop, tools, todo, subagents, skill loading, compaction, tasks, background tasks, teams, pr |
| 27 | [dair-ai/Prompt-Engineering-Guide](https://github.com/dair-ai/Prompt-Engineering-Guide) | 3 | Reference guide of prompting techniques with papers: CoT, self-consistency, ToT, ReAct, Reflexion, prompt chaining, PAL, and others |
| 28 | [microsoft/ai-agents-for-beginners](https://github.com/microsoft/ai-agents-for-beginners) | 2 | Microsoft's 16+ lesson agents course. Useful lessons: 12-context-engineering, 13-agent-memory, 09-metacognition, 03-design-patterns, 07-planning |
| 29 | [ComposioHQ/awesome-claude-skills](https://github.com/ComposioHQ/awesome-claude-skills) | 1 | Curated list of 1000+ Claude Skills and plugins, with skills like canvas-design, changelog-generator, skill-creator and video-downloader |
| 30 | [rohitg00/ai-engineering-from-scratch](https://github.com/rohitg00/ai-engineering-from-scratch) | 2 | MIT course of 542 lessons across 20 phases, with `.claude/skills` such as motion-figure, blueprint-figure, isometric-explainer, check-understanding, b |
| 31 | [asgeirtj/system_prompts_leaks](https://github.com/asgeirtj/system_prompts_leaks) | 2 | Collection of extracted vendor system prompts, including Anthropic Claude Code skills (deep-research, artifact-types, agents) under `Anthropic/claude- |
| 32 | [code-yeongyu/oh-my-openagent](https://github.com/code-yeongyu/oh-my-openagent) | 3 | Multi-agent harness/plugin (OmO) for opencode and others, with category-routed sub-agents and a skills library in `.agents/skills/` |
| 33 | [shanraisshan/claude-code-best-practice](https://github.com/shanraisshan/claude-code-best-practice) | 3 | Curated Claude Code best-practice handbook: concepts table, 83 tips, orchestration workflow (command -> agent -> skill) examples |
| 34 | [mem0ai/mem0](https://github.com/mem0ai/mem0) | 2 | Memory layer for AI agents (Python/TS SDKs plus hosted platform) with a skills/CLI integration |
| 35 | [mvanhorn/last30days-skill](https://github.com/mvanhorn/last30days-skill) | 2 | Research skill that pulls last-30-days posts and engagement from Reddit, X, YouTube, TikTok, HN, Polymarket and GitHub through a Python engine |
| 36 | [blader/humanizer](https://github.com/blader/humanizer) | 2 | Skill that edits AI-sounding prose into natural writing; 4.0 patterns numbered by strength |
| 37 | [cathrynlavery/diagram-design](https://github.com/cathrynlavery/diagram-design) | 2 | Skill that generates 45 types of branded diagrams as self-contained HTML/SVG with an editorial design system |
| 38 | [crewAIInc/crewAI](https://github.com/crewAIInc/crewAI) | 1 | Python multi-agent orchestration framework (role/goal/backstory agents, tasks, crews) |
| 39 | [coreyhaines31/marketingskills](https://github.com/coreyhaines31/marketingskills) | 2 | Library of marketing Agent Skills (ad creative, copywriting, ads, etc.) installed to `.agents/skills/`, with CLI tool wrappers |
| 40 | [hesreallyhim/awesome-claude-code](https://github.com/hesreallyhim/awesome-claude-code) | 1 | Curated awesome-list of Claude Code skills, agents, hooks, status lines and tooling; README is an index only |
| 41 | [HKUDS/DeepTutor](https://github.com/HKUDS/DeepTutor) | 2 | Personalized tutoring platform with multi-agent pipelines, including a `math_animator` pipeline (analysis -> concept design -> code generation -> rend |
| 42 | [K-Dense-AI/scientific-agent-skills](https://github.com/K-Dense-AI/scientific-agent-skills) | 1 | 177 SKILL.md files on the open Agent Skills standard, each for one package or data source, with validation checks |
| 43 | [aaif-goose/goose](https://github.com/aaif-goose/goose) | 3 | Rust general-purpose agent (CLI, desktop, API) with MCP extensions, recipes and subagents |
| 44 | [Imbad0202/academic-research-skills](https://github.com/Imbad0202/academic-research-skills) | 3 | Claude Code plugin with a research -> paper -> review -> integrity pipeline, using many role agents and human checkpoints |
| 45 | [VoltAgent/awesome-openclaw-skills](https://github.com/VoltAgent/awesome-openclaw-skills) | 1 | Curated index (~5,300) of ClawHub skills for the OpenClaw assistant. The tree is just a README plus a few files |
| 46 | [CherryHQ/cherry-studio](https://github.com/CherryHQ/cherry-studio) | 2 | Desktop AI workstation (multi-model chat, agents, knowledge bases, MCP, skills). Its `.agents/` directory is a dev-process layer |
| 47 | [elder-plinius/CL4R1T4S](https://github.com/elder-plinius/CL4R1T4S) | 2 | Archive of extracted system prompts (Anthropic, Cursor, Devin, Manus, Lovable and others). The README contains an injected "most important directive"  |
| 48 | [HKUDS/nanobot](https://github.com/HKUDS/nanobot) | 3 | Lightweight self-hosted Python agent framework with a layered memory (Consolidator + Dream) and a `.agent/` contributor guide |
| 49 | [alibaba/open-code-review](https://github.com/alibaba/open-code-review) | 3 | Go CLI for AI code review, used at Alibaba. Claims higher precision and F1 than Claude Code at about 1/9 of the tokens, and lower recall by design |
| 50 | [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) | 2 | Catalog of 2,955+ SKILL.md playbooks (formerly Antigravity Awesome Skills), plus AAS Core for local search and plan preview |
| 51 | [herdrdev/herdr](https://github.com/herdrdev/herdr) | 2 | Rust terminal runtime that hosts coding agents (Claude Code, Codex etc.) in persistent panes with per-pane status; agents drive it through a CLI/socke |
| 52 | [jeecgboot/JeecgBoot](https://github.com/jeecgboot/JeecgBoot) | 1 | Java/Vue low-code enterprise platform. It pairs with a separate Skills repo for "one sentence generates a full system" (README) |
| 53 | [DeusData/codebase-memory-mcp](https://github.com/DeusData/codebase-memory-mcp) | 3 | C MCP server that builds a persistent local knowledge graph of code, docs and infra, with 17 tools. It claims "10x lower token use and 2.1x fewer tool |
| 54 | [zhayujie/CowAgent](https://github.com/zhayujie/CowAgent) | 3 | Python 24/7 agent harness with planning, tools, skills, multi-agent teams, a 3-tier memory and self-evolution (README) |
| 55 | [luongnv89/claude-howto](https://github.com/luongnv89/claude-howto) | 2 | Tutorial and template repo covering slash commands, memory, skills, subagents, MCP, hooks, plugins and checkpoints for Claude Code (README, 10 modules |
| 56 | [harry0703/MoneyPrinterTurbo](https://github.com/harry0703/MoneyPrinterTurbo) | 3 | Python tool: topic to LLM script to stock footage to TTS to subtitles plus BGM to MP4 via MoviePy/ffmpeg (README, app/services/video.py, schema.py) |
| 57 | [debpalash/VoiceStudio](https://github.com/debpalash/VoiceStudio) | 2 | Local-first Electron voice app: cloning, design, dubbing, dictation and narration with many TTS engines (README, docs/audio-quality.md) |
| 58 | [3b1b/manim](https://github.com/3b1b/manim) | 3 | ManimGL, the programmatic math-animation engine behind 3Blue1Brown (README, default_config.yml, utils/rate_functions.py) |
| 59 | [opencv/opencv](https://github.com/opencv/opencv) | 1 | Core computer-vision library. The README is only links, so the useful content is in the videoio header (modules/videoio/include/opencv2/videoio.hpp) |
| 60 | [animate-css/animate.css](https://github.com/animate-css/animate.css) | 2 | CSS keyframe animation library (README, source/_vars.css, source/_base.css, bounceIn.css) |
| 61 | [OpenMontageInc/OpenMontage](https://github.com/OpenMontageInc/OpenMontage) | 3 | Agentic video production system. Pipeline YAMLs, per-stage director skills and provider skills under `.agents/skills/` (ffmpeg, hyperframes-*, TTS), d |
| 62 | [juliangarnier/anime](https://github.com/juliangarnier/anime) | 1 | Anime.js v4, a JS animation engine for CSS, SVG and JS objects, with timelines, stagger and springs. It has no agent or skill files, only the README a |
| 63 | [remotion-dev/remotion](https://github.com/remotion-dev/remotion) | 3 | React-to-video framework. Official agent skills live in `.agents/skills/remotion-*` (router `remotion-best-practices`, plus captions, render, multimed |
| 64 | [FFmpeg/FFmpeg](https://github.com/FFmpeg/FFmpeg) | 3 | The reference implementation of the media toolchain. `doc/ffmpeg.texi` and `doc/filters.texi` are the authoritative option docs |
| 65 | [RVC-Boss/GPT-SoVITS](https://github.com/RVC-Boss/GPT-SoVITS) | 2 | Few-shot voice cloning and TTS WebUI. Zero-shot from a 5-second sample, fine-tuning from about 1 minute of data |
| 66 | [ggml-org/whisper.cpp](https://github.com/ggml-org/whisper.cpp) | 3 | Plain C/C++ Whisper inference with word timestamps and VAD |
| 67 | [roboflow/supervision](https://github.com/roboflow/supervision) | 1 | Computer-vision utility toolkit: detections, annotators, trackers, zone counting, dataset utilities |
| 68 | [coqui-ai/TTS](https://github.com/coqui-ai/TTS) | 1 | Classic TTS library: XTTS v2 (16 languages, under 200ms streaming latency), Bark, Tortoise, 1100+ Fairseq models, fine-tuning recipes |
| 69 | [mifi/lossless-cut](https://github.com/mifi/lossless-cut) | 2 | FFmpeg GUI for lossless cutting, merging and remuxing, with a CLI, HTTP API and scene, silence and black detection |
| 70 | [OpenBMB/VoxCPM](https://github.com/OpenBMB/VoxCPM) | 3 | VoxCPM2: a 2B-parameter tokenizer-free diffusion-autoregressive TTS, 30 languages including Arabic, 48 kHz output, Apache-2.0 |
| 71 | [2noise/ChatTTS](https://github.com/2noise/ChatTTS) | 2 | Conversational TTS model (EN/ZH, 24 kHz output) with token-level prosody control; code AGPL, model CC BY-NC 4.0 (README: "academic purposes only") |
| 72 | [myshell-ai/OpenVoice](https://github.com/myshell-ai/OpenVoice) | 2 | Instant voice cloning: a tone-colour converter plus any base-speaker TTS (V2 uses MeloTTS; EN/ES/FR/ZH/JA/KO); MIT license, commercial OK |
| 73 | [TencentARC/GFPGAN](https://github.com/TencentARC/GFPGAN) | 3 | Blind face restoration with a GAN prior. It uses Real-ESRGAN for the background (inference_gfpgan.py) |
| 74 | [google-ai-edge/mediapipe](https://github.com/google-ai-edge/mediapipe) | 2 | On-device ML framework with Tasks and Studio (README). The Face Landmarker options are in tasks/python/vision/face_landmarker.py |
| 75 | [xinntao/Real-ESRGAN](https://github.com/xinntao/Real-ESRGAN) | 3 | General image and video upscaler (README and inference_realesrgan.py) |
| 76 | [babysor/MockingBird](https://github.com/babysor/MockingBird) | 1 | Mandarin voice cloning toolbox (SV2TTS: encoder, synthesizer, vocoder); the author "no longer actively updates"; MIT |
| 77 | [motiondivision/motion](https://github.com/motiondivision/motion) | 3 | Animation library (JS, React, Vue; formerly Framer Motion). The README ships an agent skill (`npx motion-ai`) |
| 78 | [pmndrs/react-three-fiber](https://github.com/pmndrs/react-three-fiber) | 2 | React renderer for three.js: JSX maps to three objects (`<mesh />` becomes `new THREE.Mesh()`) |
| 79 | [greensock/GSAP](https://github.com/greensock/GSAP) | 2 | Free JS animation platform (core, ScrollTrigger, SplitText, MorphSVG, Flip, MotionPath, Observer, ScrollSmoother; all plugins free since the Webflow a |
| 80 | [ATH-MaaS/Pixelle-Video](https://github.com/ATH-MaaS/Pixelle-Video) | 3 | Topic-to-short-video engine (canonical repo AIDC-AI/Pixelle-Video; the ATH-MaaS path was read through the redirect). Pipeline: script, image plan, per |
| 81 | [ossrs/srs](https://github.com/ossrs/srs) | 1 | Real-time media server (RTMP, WebRTC, HLS, HTTP-FLV, SRT, DASH) with DVR and transcoding hooks |
| 82 | [deezer/spleeter](https://github.com/deezer/spleeter) | 2 | TensorFlow U-Net source separation into 2, 4 or 5 stems, with pretrained models |
| 83 | [nagadomi/waifu2x](https://github.com/nagadomi/waifu2x) | 1 | CNN super-resolution and denoise for anime art, and photos with a separate model |
| 84 | [NickeManarin/ScreenToGif](https://github.com/NickeManarin/ScreenToGif) | 1 | Windows screen/webcam/sketchboard recorder with a frame editor; exports GIF, APNG, video, PSD, PNG (README) |
| 85 | [GraphiteEditor/Graphite](https://github.com/GraphiteEditor/Graphite) | 1 | Open-source node-graph vector + raster editor with a non-destructive workflow (README) |
| 86 | [airbnb/lottie-ios](https://github.com/airbnb/lottie-ios) | 1 | Native renderer for After Effects (bodymovin) JSON animations |
| 87 | [SYSTRAN/faster-whisper](https://github.com/SYSTRAN/faster-whisper) | 3 | CTranslate2 reimplementation of Whisper, up to 4x faster than openai/whisper at the same accuracy (README) |
| 88 | [iv-org/invidious](https://github.com/iv-org/invidious) | 0-1 | Open-source alternative YouTube front-end with a public API that does not use official YouTube APIs (README) |
| 89 | [danielgatis/rembg](https://github.com/danielgatis/rembg) | 3 | Background removal as a CLI, library, server or Docker image |
| 90 | [m-bain/whisperX](https://github.com/m-bain/whisperX) | 3 | Batched Whisper (faster-whisper backend) with wav2vec2 forced alignment for word timestamps and pyannote diarization. Claims 70x realtime (README) |
| 91 | [index-tts/index-tts](https://github.com/index-tts/index-tts) | 3 | Zero-shot TTS that clones a voice from one reference clip. IndexTTS-2.5 covers zh/en/ja/es/ar with emotion, speed and pronunciation control (README.md |
| 92 | [QwenAudio/CosyVoice](https://github.com/QwenAudio/CosyVoice) | 2 | Alias of FunAudioLLM/CosyVoice. LLM-based streaming zero-shot multilingual TTS, current release Fun-CosyVoice3-0.5B-2512 (README.md) |
| 93 | [amusi/CVPR2026-Papers-with-Code](https://github.com/amusi/CVPR2026-Papers-with-Code) | 0-1 | Chinese-language index of CVPR 2026 papers with code links, organised by topic (README.md) |
| 94 | [k4yt3x/video2x](https://github.com/k4yt3x/video2x) | 3 | C/C++ video super-resolution and frame-interpolation framework (6.x). It has Anime4K v4, Real-ESRGAN, Real-CUGAN and RIFE through ncnn/Vulkan, a CLI,  |
| 95 | [HeroTransitions/Hero](https://github.com/HeroTransitions/Hero) | 2 | iOS (UIKit) view-controller transition library, "similar to Keynote's Magic Move" (README.md) |
| 96 | [jlmakes/scrollreveal](https://github.com/jlmakes/scrollreveal) | 1 | Small JS library (5.7 kB) that animates elements as they scroll into view. `ScrollReveal().reveal('.sel')` (README.md). GPLv3, with a paid commercial  |
| 97 | [FreeTubeApp/FreeTube](https://github.com/FreeTubeApp/FreeTube) | 1 | Electron desktop YouTube client with privacy features, local subscriptions, SponsorBlock, DeArrow and screenshot of a video (README.md) |
| 98 | [livekit/livekit](https://github.com/livekit/livekit) | 1 | Open-source WebRTC SFU server in Go (Pion). It carries realtime audio, video and data, and the Agents framework runs voice AI on top of it (README.md) |
| 99 | [blender/blender](https://github.com/blender/blender) | 2 | Blender source repository. The README says it covers "rendering, compositing, motion tracking and video editing", and it links the manual and develope |
| 100 | [bloc97/Anime4K](https://github.com/bloc97/Anime4K) | 2 | Real-time anime upscaling and denoising shaders (GLSL for mpv, with ports). v4 adds line reconstruction (README.md, md/GLSL_Instructions_Advanced.md) |
