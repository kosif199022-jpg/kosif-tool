# قاموس البرومنت — النور، العدسة، التكوين، اللون، الخامة

اختار **كلمة لكل خانة** من الخانات دي. كتر الكلمات من نفس الخانة بيلخبط الموديل.

## النور (أهم خانة)
| الإحساس | العبارة |
|---|---|
| دراما/غموض | `low-key lighting, single hard side light, deep shadows (chiaroscuro)` |
| رقة/نعومة | `soft diffused window light, gentle falloff, low contrast` |
| بطولة | `strong backlight with a bright rim outlining the silhouette` |
| رعب/قلق | `harsh under-lighting from below, cold color` |
| دفء/حنين | `warm tungsten practical lamps, golden pools of light in a dark room` |
| نهاري طبيعي | `overcast natural daylight, soft shadows` |
| إعلان فاخر | `controlled studio lighting, large softbox overhead, crisp specular highlights` |
| نيون | `colored practical neon light in magenta and cyan, wet reflections` |
| سينما ليل | `moonlight blue ambient with a single warm practical as key` |
القاعدة: **مصدر رئيسي واحد + اتجاهه + لونه + جودته (hard/soft)**.

## العدسة وحجم اللقطة
| العدسة | التأثير |
|---|---|
| 14–24mm | واسع، مكان، تشويه درامي (بعيد عن الوش) |
| 35mm | قصصي، طبيعي، شارع |
| 50mm | عين الإنسان، محايد |
| 85mm | بورتريه، خلفية ناعمة |
| 100mm macro | منتج، تفاصيل |
| 135–200mm | ضغط المسافات، تجسس، خلفية مسطحة |
الأحجام: `extreme wide shot, wide shot, medium shot, medium close-up, close-up, extreme close-up, over-the-shoulder, insert shot`.
الزوايا: `eye level, low angle (قوة), high angle (ضعف), bird's-eye view, dutch angle (اضطراب), worm's-eye view`.
العمق: `shallow depth of field, f/1.4` ↔ `deep focus, f/11`.

## التكوين
`rule of thirds` · `centered symmetrical composition` · `leading lines toward the subject` · `frame within a frame (doorway, window)` ·
`foreground elements out of focus` · `negative space on the right for a title` · `silhouette against the bright sky` · `layered depth: foreground, midground, background`.

## اللون والجريد
| اللوك | العبارة |
|---|---|
| تيل وأورانج | `teal and orange color grade` |
| فيلم دافي | `warm film look, Kodak-style color, soft halation, fine grain` |
| بارد شمالي | `cold desaturated palette, steel blues and greys` |
| بليتش باي باس | `bleach bypass look, desaturated, high contrast, silvery highlights` |
| أحادي اللون | `monochrome [color] palette` |
| قديم | `faded 1970s film photograph, lifted blacks, warm cast` |
| أبيض وأسود | `black and white, rich blacks, high micro-contrast` |
وحّد اللوك النهائي محليًا: `forge.py fx ... --fx grade:<preset>:0.4,grain:0.2` (presets: teal_orange, golden, night_blue, cold, bleach, desert, neon, fire).

## الخامات والتفاصيل اللي بتعمل الواقعية
`natural skin texture with visible pores` · `fine fabric weave` · `brushed aluminum` · `condensation droplets on cold glass` ·
`worn leather with creases` · `dust on the surface` · `fingerprints on the glass` · `subtle imperfections`.
الواقعية = عيوب صغيرة مقصودة، مش «ultra realistic».

## المشاعر ← قرارات بصرية
| الشعور | نور | لون | عدسة | حركة (Kling) |
|---|---|---|---|---|
| وحدة | خلفي ضعيف | بارد باهت | واسعة، موضوع صغير | pull back بطيء |
| قوة | low-key جانبي | تباين عالي | زاوية واطية 24–35mm | slow push in / orbit |
| أمل | شروق دافي | ذهبي | 35–50mm | crane up |
| توتر | أندر لايت/نيون | أخضر/أزرق | 135mm ضاغطة | handheld خفيف |
| فخامة | ستوديو متحكم | أسود + ذهبي | 100mm | orbit بطيء جدًا |
| حنين | تنجستن دافي | فيلم باهت | 50mm | static + غبار في الضوء |

## ستايلات غير فوتوغرافية (لما تكون مطلوبة)
`oil painting with visible brush strokes` · `ink and watercolor illustration` · `paper cut-out diorama` · `claymation` ·
`isometric 3D render, soft studio light` · `retro screen print poster, limited 3-color palette` · `Islamic geometric pattern art` · `charcoal sketch`.
ماتستخدمش اسم فنان حي أو اسم عمل محمي؛ اوصف خصائص الأسلوب.
