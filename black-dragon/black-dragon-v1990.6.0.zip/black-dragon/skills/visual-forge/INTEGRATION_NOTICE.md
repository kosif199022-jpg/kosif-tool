# Visual Forge Source Provenance

Source: `visual-forge.zip` supplied by the user on 2026-11-09. The original `scripts/forge.py` is kept byte-exact at `upstream/forge-original.py`. The active `scripts/forge.py` contains small practical alpha/audio fixes. `tools/visual_forge/bridge.py` is new integration code. The archive did not include a LICENSE file; rights not independently verified.
