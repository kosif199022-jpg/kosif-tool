# الأزياء (Fashion) — ستايلينج، تصوير، فيلم، وبرومبتات AI

## الفهرس
1. أساسيات الـ Styling
2. الأقمشة والخامات (Fabric vocabulary)
3. العصور والـ Subcultures + التراث المصري والعربي
4. تصوير الأزياء (Photography)
5. فيلم/ريلز الأزياء
6. Prompt vocabulary للـ AI + 10 برومبتات + الثبات (consistency)
7. Creative Direction + 15 كونسبت
8. Critique checklist (10 نقاط)

---

## 1. أساسيات الـ Styling

### Silhouette & Proportion
- الـ silhouette هو أول حاجة العين بتقراها قبل اللون والخامة. قرّر شكل الظل الأول: A-line، column، hourglass، oversized/boxy، inverted triangle، cocoon.
- قاعدة التوازن: لو فوق واسع (oversized shirt) خلّي تحت ضيق أو مستقيم؛ ولو تحت واسع (wide-leg) خلّي فوق مقصوص أو متدخّل (tucked).
- **Rule of thirds** في الجسم: خط الوسط/البنطلون العالي (high-rise) بيطوّل الرجل. قسمة 1:2 أحسن من 1:1.
- طول الكم، طول الهيم، وفين بينتهي الجاكيت = قرارات proportion. سنتيمترين بيغيّروا الإحساس كله.
- الـ negative space بين الجسم والقماش (في الـ oversized والـ volume) هو اللي بيعمل حركة في الكاميرا.
- الـ monochrome head-to-toe بيطوّل ويدّي إحساس luxury؛ بس لازم تنويع في texture عشان ماتبقاش مسطّحة.

### Color & Contrast مع لون البشرة
- اعتمد على **undertone** (warm / cool / neutral) مش بس درجة البشرة.
- بشرة قمحاوي/خمرية دافية (الأغلب في مصر): الذهب، الزيتي، التيراكوتا، الكريمي، الأزرق الملكي، الزمردي، الفوشيا، الأبيض المكسور — كلهم بيلمعوا. الأبيض الناصع ممكن يقسّي؛ استخدم ivory/ecru.
- بشرة غامقة: ألوان مشبعة (cobalt، canary yellow، hot pink، emerald) بتعمل contrast جامد؛ والباستيل الباهت ممكن يغسل لو من غير تدرّج.
- بشرة فاتحة: jewel tones وعميقة (burgundy، forest) بتدّي عمق؛ تجنّب الألوان اللي قريبة من لون البشرة (nude مش مظبوط) إلا لو مقصود.
- الـ contrast أنواع: value (فاتح/غامق)، temperature (دافي/بارد)، saturation. اختار **نوع واحد** يقود.
- قاعدة 60-30-10: لون أساسي، ثانوي، accent.
- الكاميرا والإضاءة بتغيّر اللون: التنجستن بيصفّر، الشمس العالية بتبيّض الأبيض. اعمل color test قبل اليوم.

### Layering
- ابدأ من الأخف للأتقل في الخامة، وللأطول للأقصر في الطول (long coat فوق shorter jacket فوق shirt).
- كل layer لازم يبان منه حاجة (cuff، collar، hem) — ده اللي بيدّي depth.
- غيّر الـ texture بين الطبقات: حرير تحت صوف، شيفون فوق جيرسيه.
- في الصيف المصري: layers خفيفة (sheer organza، linen duster، open shirt) بدل الأتقال، عشان الموديل ماتعرقش في الكادر.

### Texture Mixing
- مزج مضمون: matte + shine (صوف + ساتان)، soft + structured (knit + leather)، rough + refined (linen + silk).
- ماتجمعش أكتر من 3 textures قوية في لوك واحد إلا لو ده الـ maximalism المقصود.
- الـ shine مكان واحد غالباً (قطعة واحدة لامعة) والباقي matte.

### Accessories
- الإكسسوار بيحكي الشخصية: أحزمة، نظارات، شنط، أحذية، مجوهرات، طرح/إيشارب، قبعات.
- قاعدة Coco: بص في المراية واشيل قطعة. لو عايز max، اعمل **stacking** مقصود (خواتم، أساور) مش عشوائي.
- المعدن: اتّسق (ذهب مع ذهب) أو امزج بقصد (two-tone بشكل واضح).
- الإكسسوار في الـ close-up (قرط، خاتم، ساعة) بيبقى بطل الشوت؛ لمّعه وجهّزه.

### قاعدة "قطعة Statement واحدة"
- لوك واحد = بطل واحد (معطف ضخم، فستان فلوري، حذاء جريء، قبعة). الباقي يدعمه ويهدّى.
- لو في بطلين، خلّيهم في تباين واضح (واحد volume وواحد لون) أو وزّعهم على لقطات مختلفة.
- اسأل: العين هتروح فين أول ثانية؟ لو مش واضحة، اشيل حاجة.

### Modest Fashion بحس High-Fashion
- الاحتشام مش قيد، ده مساحة للـ volume والـ drape والـ proportion — زي ما عمل Rick Owens وIssey Miyake وmodest designers عرب.
- ركّز على: layering ذكي، قصّات طويلة نظيفة، أكمام بحجم (bishop، balloon، bell)، خامات بتتحرك (crepe، satin crepe، chiffon فوق lining).
- لوك جاهز: long trench + wide-leg trousers + knit under-layer + hijab من حرير مطبوع مربوط كـ sculptural drape.
- الحجاب كعنصر تصميم: اللون يتكرر في حاجة تانية (حزام، شنطة)، الخامة مناسبة للوش (matte للوش المضيء)، والتثبيت يبان شيك مش شغل pins ظاهر.
- الـ abaya الحديثة: open-front duster، pleated، embroidered cuffs، belted.
- تصوير: متقصّش الفستان ولا تلصّق أي sensual lighting غير لائق؛ حافظ على الاحترام. الحركة والخامة هما الجاذبية.
- استشر الموديل: إيه المريح لها وإيه حدودها قبل التصوير.

---

## 2. الأقمشة والخامات (إزاي بتظهر قدام الكاميرا)

| الخامة | إزاي بتقرأ في الكاميرا والضوء |
|---|---|
| **Silk** | لمعة ناعمة، drape سائل، بيعكس الضوء بدرجات؛ بيبان فيه كل كرمشة؛ مناسب soft light مع kicker |
| **Satin** | لمعة عالية، highlights حادة، بيطلع specular؛ تجنب الضوء المباشر الحاد عشان ماتتحرقش اللمعة |
| **Chiffon** | شفاف، خفيف جداً، بيطير مع أقل هوا؛ ممتاز backlit؛ محتاج lining أو layering |
| **Organza** | شفاف ومنتصب (stiff)، بيعمل volume ونحت، حواف حادة، لمعة ناعمة؛ حلو في الضوء الخلفي |
| **Linen** | كرمشة طبيعية، matte، حبيبة واضحة؛ إحساس صيفي عضوي؛ ممتاز في الشمس والـ golden hour |
| **Wool** | matte، بيمتص الضوء، بيدّي structure؛ التفاصيل (twill، herringbone) بتبان في side light |
| **Denim** | texture واضحة، تدرّجات الغسيل، خياطة بارزة؛ الضوء الجانبي بيبرز النسيج |
| **Leather** | specular highlights، بيعكس اللي حواليه؛ محتاج softbox كبير عشان انعكاسات نضيفة؛ الكرمشة تدّي طابع |
| **Velvet** | بيمتص الضوء وبيلمع على الحواف (sheen) حسب اتجاه الوبر؛ ألوان عميقة؛ side/rim light بيطلع الجمال |
| **Sequins** | بتلمع وتتشظى (sparkle)؛ ضوء نقطي صغير بيطلّع glints؛ في الفيديو بتعمل twinkle؛ احذر الـ moiré والـ clipping |
| **Lamé** | معدني سائل، بيعكس بشدة؛ زي المراية؛ خلّي الخلفية مسيطر عليها |
| **Tulle** | شبكي ناعم، volume هوائي، بيعمل layers شفافة؛ حلو backlit وفي الـ slow motion |
| **Jersey** | بيتمدد ويلزق بالجسم، matte ناعم؛ بيوضّح الـ silhouette (ممكن يفضح، فاحذر الخطوط) |
| **Knit** | texture ملموسة (cable، rib، chunky)؛ دفا بصري؛ side light بيعمق الغُرز |
| **Brocade** | نسج مزخرف بخيوط معدنية، سميك وبيحافظ على شكله؛ فخامة تراثية؛ ضوء ناعم عشان ما يتشوّش النقش |
| **Egyptian cotton** | قطن طويل التيلة: مصقول، نقي، ناعم، لمعة خفيفة جداً؛ قمصان بيضا نضيفة، بياضه بيحتاج exposure دقيق |

نصايح سريعة:
- اللمعة (sheen) بتتحكم فيها **حجم** مصدر الضوء وزاويته: كبير وقريب = لمعة ناعمة ومتدرّجة، صغير وبعيد = highlights حادة.
- الشفاف بيحتاج خلفية متحكَّم فيها وإلا بيبان اللي وراه.
- الخامات المتحركة (chiffon، tulle، silk) تتصوّر بمروحة أو هوا طبيعي، وshutter سريع للـ stills.
- في الـ AI قل الخامة صراحة + سلوكها (flowing، stiff، clinging).

---

## 3. العصور والـ Subcultures كـ Styling Toolkit

### توقيعات العقود
- **1920s**: drop-waist، beaded flapper dresses، cloche hats، لؤلؤ طويل، headbands، Art Deco.
- **1930s**: bias-cut satin gowns، أكتاف ناعمة، backless، waves شعر.
- **1940s**: أكتاف مبطّنة (padded shoulders)، utility suiting، tea dresses، headscarves.
- **1950s**: New Look: خصر ضيق وتنورة circle، pencil skirts، cat-eye، قفازات، Dior.
- **1960s**: mod، mini، shift dresses، Mary Quant، color-blocking، space-age (Courrèges)، go-go boots.
- **1970s**: bell-bottoms، suede، fringe، earth tones، Halston jersey، disco lamé، bohemian.
- **1980s**: power shoulders، neon، leggings، oversized blazers، glam، Memphis patterns.
- **1990s**: minimalism، slip dress، grunge، baggy denim، baby tee، Calvin Klein، supermodel era.
- **2000s / Y2K**: low-rise، baby tee، rhinestones، metallics، velour tracksuits، mini bags، butterfly clips، chrome.
- **2010s**: normcore، athleisure، sneaker culture، Instagram boho، statement collars.
- **2020s**: quiet luxury، gorpcore، Y2K revival، dopamine dressing، sheer/mesh، sustainable & vintage.

### Subcultures وستايلات
- **Quiet luxury**: neutral palette (camel، cream، grey)، cashmere، tailoring ممتاز، من غير لوجو، cut > decoration.
- **Streetwear**: hoodies، cargo، sneakers، graphic tees، caps، layering رياضي؛ مزاج urban.
- **Techwear**: خامات تقنية (Gore-Tex)، أحزمة وbuckles، أسود/رمادي، utility pockets، modular.
- **Gorpcore**: outdoor gear كموضة: fleece، windbreaker، trail shoes، ألوان طبيعية.
- **Avant-garde / Deconstruction**: خياطة مكشوفة، asymmetry، قطع مقلوبة، unfinished hems (Margiela، Comme des Garçons)، proportion مكسور.
- **Minimalism**: خطوط نظيفة، ألوان محدودة، cut ممتاز، كل تفصيل له سبب.
- **Maximalism**: patterns clashing، ألوان كتير، طبقات، إكسسوار عالي — لكن بنظام (لون رابط).

### التراث المصري والعربي (استخدام محترم، مش costume)
- **القفطان (kaftan)**: قصّة واسعة وطويلة؛ حرير/ساتان/مطرّز؛ ممكن يتقدّم modern بحزام وخامة معاصرة.
- **الجلابية**: مصرية صميمة، قطن/صوف؛ ممكن تتحوّل لـ oversized shirt-dress أو تتلبس مع sneakers/جاكيت tailored. ماتتقدّمش كمسخرة.
- **الطربوش**: رمز عصر الأفندية (أواخر 19 – منتصف 20)؛ استخدمه في تصوير vintage/period جاد، أو كعنصر سينمائي، مع أحترام السياق.
- **العباية**: قصّات حديثة (open duster، pleated، embroidered)؛ مادة حرير/كريب/ساتان؛ الحركة تعمل شكل بديع.
- **تطريز البدو وسيوة**: تطريز سيوة بأقراص فضة وخرز وألوان أحمر/أسود/أبيض، تطريز سيناء جيومتري (cross-stitch). استخدمه كـ detail (ياقة، كم، شنطة) مش قناع.
- **منسوجات صعيد**: الشيش، قطن مخطط، شالات، الصوف اليدوي، أخميم (حرير وقطن منسوج يدوي) — نسيج غني ببصمة يدوية.
- **القطن المصري** والـ khayamiya (قماش الخيامية) كخلفية/إكسسوار.
- **القاهرة الذهبية 1950s–60s**: فساتين cinched بنات الأفلام، نظارات شمس كبيرة، قفازات، bouffant hair، eyeliner مجنّح، تايورات، ألوان باستيل، سينما فاتن حمامة وسعاد حسني؛ مزاج وسط البلد وكورنيش النيل.
- **قواعد الاحترام**: افهم معنى القطعة، اشتغل مع حرفيين/مصممين محليين لو ممكن، ماتخلطش ثقافات عشوائياً، ولا تستخدم رموز دينية أو مقدسة كأزياء، وقدّم القطعة بكرامة وتفاصيلها الحقيقية.

---

## 4. تصوير الأزياء

### الأنواع
- **Editorial**: قصة وفكرة ومزاج؛ حرية فنية؛ الأزياء جزء من حكاية؛ ممكن يكسر قواعد.
- **Commercial / Campaign**: بيع منتج/براند؛ وضوح + هوية؛ الموديل والمنتج واضحين؛ مراجعة من العميل.
- **E-commerce / Lookbook**: وضوح التفاصيل، إضاءة نضيفة ثابتة، خلفية بسيطة، زوايا قياسية (front، back، side، detail)، لون دقيق، مقاسات.

### Posing Direction
- ابدأ من الأرض: وزن الجسم على رجل واحدة، الركبة مثنية شوية، الأكتاف مش متماثلة.
- **الزوايا**: ثلاثة أرباع (3/4) للجسم أحلى من المواجهة التامة؛ الوش قدّام الجسم بزاوية.
- **الأيدي**: أكبر عدو. ادّيهم مهمة (ياقة، جيب، شعر، حزام، حافة معطف)، أصابع مفرودة ومرتخية، مش مقبوضة، وماتخبيش كل الإيد.
- **الرقبة والذقن**: ذقن لقدّام وتحت شوية يمنع الذقن المزدوج؛ رقبة طويلة.
- **الحركة**: خطوة، لفة، سحب القماش، مسك طرف الفستان، قفزة بسيطة. سيب الموديل يتحرك وسجّل بـ burst.
- أمثلة أوامر: "اتحركي بالراحة كأنك سامعة أغنية"، "بصي عن كتفك"، "الإيد على الياقة وسيبي النفس"، "امشي ناحية الكاميرا وبعدين وقفي".
- نوّع بين poses ثابتة وحركية، وبين قريب وواسع.

### إعدادات الإضاءة
- **Beauty dish**: ضوء ناعم-حاد (crisp) بتباين حلو على الوش وعظام الخد؛ فوق الكاميرا وبزاوية لتحت. مثالي للـ beauty/editorial.
- **Ring light**: إضاءة مسطحة بدون ظلال، catchlight دايري في العين؛ شكل "fashion 2000s/ Instagram".
- **Hard sun**: ظلال حادة وتباين عالي، شكل Mediterranean/Egyptian summer؛ استخدم عاكس/diffuser، أو اللعب بالظل الحاد كعنصر جرافيكي. أفضل وقت: golden hour أو الصبح المبكر.
- **Strobe + Gel**: فلاش بجل ملوّن (cyan، magenta، amber) على الخلفية أو rim؛ مزاج جريء؛ وازن مع الـ ambient بـ slow shutter drag.
- **Softbox كبير/Octabox** للوك commercial ناعم، **strip softboxes** للحواف (rim) على الأقمشة اللامعة.
- **Backlight** للأقمشة الشفافة (chiffon، tulle).
- **Window light**: سهل وجميل للـ lookbook؛ استخدم عاكس أبيض.

### خلفيات ولوكيشنات مصرية شغّالة
- **وسط البلد القاهرة**: عمارات خديوية، بلكونات حديد، مداخل رخام، شبابيك خشب؛ مزاج 50s-60s.
- **خان الخليلي / المعز / الأزهر**: نسيج معماري، فوانيس، أخشاب مشربيّة؛ احترم الناس والمحلات.
- **الأهرامات / الصحراء**: بلاتو الجيزة، كثبان سقارة، وادي الحيتان؛ ألوان رملية، sun hard، سماء واسعة؛ تأكد من تصاريح.
- **سيوة**: الملح، البحيرات، شالي، رمال بيضاء؛ ممتازة لتطريز سيوة.
- **أسوان والنوبة**: بيوت ملونة، النيل والفلوكة، ألوان زاهية؛ نسيج الصعيد.
- **الساحل الشمالي والإسكندرية**: كورنيش، قلاع، رمل أبيض وبحر أزرق؛ بياضات كتان ولوكات صيفية.
- **الجونة / دهب / الغردقة**: بحر وخلجان.
- **القاهرة الفاطمية والإسلامية**: مساجد (خارجياً، باحترام وبالإذن وباللبس المناسب)، أقواس.
- **مصانع/ورش مهجورة، أسطح عمارات، جراجات**: لـ streetwear/techwear.
- **الصحراء البيضاء**: كأنها كوكب تاني؛ مثالية لـ avant-garde.
- نصيحة: اسأل عن التصريح لو معاك معدات؛ وراقب الزحمة والشمس؛ الأفضل شروق/غروب.

---

## 5. فيلم/ريلز الأزياء

- **الحركة تقود المونتاج**: قص على الحركة (match on action)، مش على الصمت. كل قطعة تتحرك: لفة، مشية، قماش بيطير.
- **القماش في Slow motion**: صوّر 60–120 fps واعرض 24/25؛ شيفون/تول/ساتان بتبقى شعر. محتاج ضوء قوي عشان shutter سريع (180° rule: مثلاً 1/120 مع 60fps).
- **الهوا**: مروحة خارج الكادر، أو حد يشد القماش بخيط شفاف، أو رمي القماش، أو الريح الطبيعية على الساحل/الصحراء. وجّه الهوا من الجنب عشان القماش يتفرد.
- **الإيقاع مع الموسيقى**: اقطع على الـ beat أو على الـ off-beat بقصد؛ drop = تغيير لوك؛ بنية 4 أو 8 كات. حدّد الأغنية قبل المونتاج؛ تقدر تولّد موسيقى مخصصة.
- **Transitions بتغيير اللبس**:
  - **Cut on spin**: لفّة سريعة وتقطع في منتصفها للوك الجديد، بنفس الحركة والاتجاه.
  - **Cover the lens**: إيد أو قماش يغطي العدسة ويخرج في لوك تاني.
  - **Jump / snap / clap**: صفقة أو تكّة إصبع تغيّر اللوك.
  - **Door/wall wipe**: تمر بالكاميرا خلف حاجة وتخرج مختلفة.
  - **Match cut** بالشكل/اللون (دايرة الكم → دايرة الشمس).
  - ثبّت الكاميرا في نفس المكان والـ framing عشان الانتقال ما يبانش.
- **Runway-style walk-cycle**: مشية مستقيمة، خطوة قدام الرجل، كتف ثابت، نظرة بعيد؛ شوت tracking أو front-facing ثابت، low angle عشان القوة؛ توقف وlook ثم لفة.
- **لقطات**: wide للـ silhouette، medium للوك، detail (قماش، حذاء، إيد)، low angle، reveal بحركة كاميرا (push-in، orbit، whip pan).
- **Speed ramping**: يبدأ عادي ثم slow عند اللحظة الجمالية.
- **Vertical 9:16** للريلز: الحركة تتجه رأسياً، اترك مساحة للنص في الأعلى/الأسفل، ابدأ بـ hook في أول ثانيتين.
- **Color grade** موحّد يخلّي الكوليكشن متماسك.

---

## 6. Prompt Vocabulary لموديلات الـ AI (صور وفيديو)

### قالب منظم (Structured Template)
```
[Subject: age/ethnicity/hair/expression]
[Garment: type + fabric + cut/silhouette + color + details]
[Styling: accessories, shoes, hair, makeup]
[Pose / action]
[Location / background]
[Light: type, direction, quality, time]
[Lens / camera: focal length, aperture, angle, framing]
[Film stock / look: grain, grading, era]
[Mood / aesthetic keywords]
```
نصايح:
- ابدأ بالأهم (الموديل واللبس). استخدم تفاصيل ملموسة بدل صفات عامة.
- الخامة + السلوك: "flowing silk satin with soft specular highlights" أحسن من "nice dress".
- حدد العدسة: 35mm (قصة)، 50mm (طبيعي)، 85mm (portrait ناعم)، 24mm (دراماتيك).
- اللغة الإنجليزية في البرومبت غالباً بتدّي نتيجة أدق.
- أضف negative لو مدعوم: "extra fingers, distorted hands, warped text, plastic skin".
- للفيديو: وصف حركة واحدة واضحة + حركة كاميرا + سرعة ("slow motion", "dolly in").

### 10 برومبتات كاملة

1. **Editorial – Desert avant-garde**
`A tall Egyptian woman with sleek low bun and bold graphic eyeliner, wearing a sculptural oversized cocoon coat in stiff ivory organza with exaggerated sleeves over a matte black column dress, barefoot, standing on white sand dunes of the White Desert, wind lifting the coat, low-angle full-body shot, hard late-afternoon sun with long shadows, 35mm lens f/4, Kodak Portra 400 look with fine grain, surreal quiet futuristic mood`

2. **Modest high fashion – Cairo downtown**
`A young woman in a silk hijab draped sculpturally in deep emerald, wearing a long belted camel trench coat over wide-leg cream trousers and a chunky knit layer, gold minimal jewelry, walking down a 1950s Khedivial street in Downtown Cairo with ornate balconies, soft overcast light, 50mm lens f/2.8, medium-full shot, muted warm editorial colors, elegant confident mood`

3. **1950s Cairo glamour**
`A glamorous woman in 1950s Cairo cinema style: nipped-waist satin dress in powder blue with a full circle skirt, white gloves, cat-eye winged eyeliner, bouffant hair, oversized sunglasses, sitting on a Nile corniche bench with a vintage Cadillac behind, golden hour backlight, 85mm lens f/2, Kodachrome film look, soft nostalgic cinematic mood`

4. **Streetwear – Alexandria**
`A young Egyptian man in oversized heavyweight washed-black hoodie, wide cargo pants, chunky white sneakers, silver chain, beanie, leaning against a graffiti wall by the Alexandria corniche at dusk, low-angle wide shot, 24mm lens, strobe with cyan gel as rim light mixed with ambient blue hour, subtle film grain, edgy urban mood`

5. **Quiet luxury – lookbook**
`A woman in a head-to-toe neutral outfit: oatmeal cashmere sweater, tailored wool trousers in camel, leather loafers, no logos, standing in a minimalist sunlit apartment with linen curtains, large window softbox-like light, 50mm lens f/2.2, clean high-resolution e-commerce lookbook framing, calm refined mood`

6. **Maximalist – Khan el-Khalili**
`A model layering clashing patterns: embroidered Siwa-inspired red and black tunic over a brocade skirt in gold and teal, stacked silver bangles and chunky necklaces, standing under glowing brass lanterns in Khan el-Khalili, warm tungsten mixed light, 35mm lens f/2, rich saturated colors, festive joyful maximalist mood`

7. **Techwear – night city**
`A figure in a black techwear parka with matte waterproof fabric, utility straps and buckles, modular cargo pants, reflective details, face covered with sleek visor, standing on a rainy Cairo rooftop at night with neon signs, cinematic wide shot, cool teal and magenta lighting, 28mm lens, Cinestill 800T halation look, futuristic cyberpunk mood`

8. **Fashion film (video) – flowing chiffon**
`Video: a model in a flowing sheer champagne chiffon gown spins slowly on a Mediterranean beach at sunrise, the fabric billowing in the wind, slow motion 120fps look, camera gently orbiting around her, backlit golden light, cinematic shallow depth of field, dreamy romantic mood`

9. **Runway walk (video)**
`Video: a model in a structured black satin blazer with exaggerated shoulders and wide-leg trousers walks confidently down a minimalist white runway toward camera, front-facing locked-off shot, soft high-key light, steady walk cycle, small head turn at the end, crisp fashion show aesthetic`

10. **Modern galabeya reinterpretation**
`A stylish Egyptian man in a modern interpretation of a galabeya: tailored off-white Egyptian cotton long shirt-coat with clean collar, paired with leather sandals and a structured shoulder bag, standing on a Luxor Nile felucca at golden hour, 50mm lens f/2.8, warm natural light, subtle film grain, proud elegant contemporary heritage mood`

### الثبات (Consistency) في اللبس عبر اللقطات
- اعتمد على **صورة مرجعية** (reference image) للموديل واللبس، واستخدم نفس الـ seed أو character/reference feature لو متاح.
- اكتب **وصف اللبس بنفس الكلمات حرفياً** في كل برومبت (garment lock): "ivory organza coat with stiff bell sleeves, mother-of-pearl buttons".
- حدّد تفاصيل لا تتغير: لون دقيق (hex أو اسم دقيق مثل "burnt terracotta")، عدد الأزرار، شكل الياقة، النقشة.
- ابدأ بـ **لقطة master** (full-body front) وبعدين ولّد زوايا منها (image-to-image أو reference).
- ثبّت الإضاءة والـ look في جملة موحّدة (style block) تتكرر.
- في الفيديو: ابدأ من first frame ثابت وخلّي الحركة قصيرة (3–5 ثواني) عشان اللبس ما يتغيرش، وبعدين اربط اللقطات في المونتاج.
- راجع الدقة: أزرار، جيوب، حواف، إكسسوار — الـ AI بيضيع هنا. أصلح بـ inpainting.
- لو اللبس حقيقي، ارفع صورة المنتج كمرجع وحافظ على الشعار والنقوش الحقيقية.

---

## 7. Creative Direction

### بناء قصة الكوليكشن / المود
1. **سؤال واحد**: الكوليكشن بيحكي إيه؟ (ذكرى، مكان، شخصية، فكرة؟)
2. **Mood board**: 12–20 صورة (ألوان، خامات، لوكيشن، إضاءة، حركة) — ماتنسخش، استلهم.
3. **Palette**: 3–5 ألوان + accent. **Texture palette**: 3 خامات رئيسية.
4. **Character**: مين اللي بيلبس؟ بيمشي فين؟
5. **Shot list**: hero looks، detail shots، movement shots، quiet frames.
6. **Rhythm**: ترتيب اللقطات والإيقاع (لقطة قوية، هدوء، قوية).
7. **قاعدة**: كل لقطة تخدم الفكرة، وإلا اشيلها.

### 15 كونسبت أصلي
1. **"ملح سيوة"**: تطريز سيوة على خلفية بحيرات ملح، أبيض على أبيض مع لمسات فضة.
2. **"أفندي 2050"**: طربوش مستقبلي منحوت مع بدلة tailored معدنية، زمن مختلط.
3. **"نيل على الجسد"**: قماش ساتان أزرق يتدفق كالمياه، تصوير على فلوكة.
4. **"سينما وسط البلد"**: بنات 60s بقصّات حديثة، أمام أفيشات أفلام قديمة.
5. **"الصحراء البيضاء كوكب تاني"**: avant-garde بقطع منتصبة من organza على صخور الكريستال.
6. **"عباية الضوء"**: عبايات pleated شفافة مع ضوء خلفي وقت الغروب.
7. **"ورشة الصعيد"**: نسيج أخميم وشيش، حرفيين حقيقيين وهم بيشتغلوا، سرد وثائقي-مودا.
8. **"نيون الأزبكية"**: streetwear مع إضاءة نيون وكتب قديمة.
9. **"القطن الأبيض"**: كل اللوكات من القطن المصري الأبيض، اختلاف في القصّات بس.
10. **"فرح الحارة"**: maximalism بألوان زينة الفرح والخيامية والفوانيس.
11. **"المحطة الأخيرة"**: ركوب مترو/قطر، لوكات واقعية commute-couture.
12. **"سراب"**: لوكات فضية/ذهبية lamé وسط حرارة الصحراء، تموّجات هوا.
13. **"قفطان الغروب"**: قفطان واحد بخمس طرق تلبيس عبر اليوم.
14. **"صمت المعبد"**: minimalism مع أعمدة ومعابد، لوكات monochrome بنفس ألوان الحجر.
15. **"ذاكرة الجدة"**: ملابس مستوحاة من دولاب الجدة (دانتيل، لؤلؤ، بروش) بتفاصيل vintage حقيقية وprop ذكريات.

---

## 8. Critique Checklist (10 نقاط)

1. **الفكرة**: هل اللقطة بتحكي حاجة واضحة وجملة واحدة تلخصها؟
2. **البطل**: هل العين بتروح لقطعة/وش واحد أول ما تشوف الصورة؟
3. **Silhouette & proportion**: الشكل العام نضيف؟ مفيش قص غلط (tangents، قص مفصل)؟
4. **اللون**: متناسق مع البشرة والخلفية؟ والـ palette مضبوط؟
5. **الخامة**: هل الخامة بتبان صح (لمعة، شفافية، نسيج)؟ والكرمشة مقصودة؟
6. **الإضاءة**: الاتجاه والجودة مناسبين للخامة والمزاج؟ مفيش highlights محروقة أو ظلال بتكتم؟
7. **البوز والإيدين**: طبيعية؟ الإيدين والرقبة والكتف مرتاحين؟
8. **الخلفية واللوكيشن**: بتدعم القصة ولا بتشتّت؟ مفيش عناصر عشوائية؟
9. **التفاصيل الصغيرة**: كي، خيوط، حواف، إكسسوار، شعر، مكياج، أظافر نضيفة؟ (وفي الـ AI: أصابع، أزرار، نص مشوّه).
10. **الاتساق والاحترام**: اللقطة متسقة مع باقي الكوليكشن؟ والتراث/الثقافة مستخدمين باحترام وبدون ابتذال؟
