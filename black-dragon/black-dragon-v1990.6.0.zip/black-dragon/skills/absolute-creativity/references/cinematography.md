# التصوير السينمائي والفوتوغرافي الإبداعي (Cinematography & Photography)

> القاعدة الذهبية: كل لقطة لازم تجاوب على سؤال واحد: **"اللقطة دي بتقول إيه، وليه كده بالذات؟"** لو الإجابة "عشان شكلها حلو" يبقى لسه ما اتصممتش.

## TOC
1. Shot design: الأحجام والزوايا
2. جدول emotion → shot
3. Lens psychology
4. Composition أبعد من rule of thirds
5. Camera movement + الدافع
6. Lighting
7. إضاءة رخيصة بالموبايل
8. Photography quick guide
9. Blender equivalents + bpy
10. عشرين فكرة لقطة مبتكرة
11. Shot list template
12. Critique checklist (10 أسئلة)

---

## 1. Shot design: الأحجام والزوايا

### أحجام اللقطة (Shot sizes)
| الحجم | الاختصار | بيقول إيه | استخدمه لما |
|---|---|---|---|
| Extreme Wide / Establishing | EWS | الإنسان صغير، العالم أكبر منه، وحدة أو عظمة | افتتاح، مكان، عزلة |
| Wide | WS | الشخص + بيئته، سياق | توضيح العلاقة بالمكان |
| Full | FS | لغة الجسم كلها | حركة، رقص، دخول |
| Medium / Cowboy | MS / MCU | حوار طبيعي، تواصل | كلام عادي، تعليم |
| Medium Close-Up | MCU | قرب من غير اقتحام | interview، vlog |
| Close-Up | CU | مشاعر، نية | لحظة قرار، دمعة |
| Extreme Close-Up | ECU | هوس، توتر، تفصيلة حاسمة | عين، إيد بترتعش، ساعة |
| Insert | - | تفصيلة بتحكي (رسالة، مفتاح) | معلومة بصرية سريعة |

قاعدة: **كل ما قربت زادت الحميمية والضغط. كل ما بعدت زاد الحياد أو العزلة.**

### الزوايا (Angles)
| الزاوية | الأثر النفسي | ملاحظة تنفيذ |
|---|---|---|
| Eye-level | حياد، صدق، تواصل | الافتراضي للـ talking head |
| Low angle (من تحت) | قوة، هيبة، تهديد، بطولة | الكاميرا تحت الذقن؛ مبالغة = كاريكاتير |
| High angle (من فوق) | ضعف، صغر، ضياع، مراقبة | حلو لشخص محتار |
| Dutch / canted | اختلال، قلق، جنون | 10-25 درجة بس، وبدافع (مش طول الفيلم) |
| Overhead / top-down | God view، تصميم، نظام، طعام | ممتاز للـ flat-lay وفيديوهات الطبخ |
| POV | انغماس، "أنت هنا" | إيد المصوّر تظهر = أقوى |
| Over-the-shoulder (OTS) | علاقة، مواجهة، حميمية | الكتف في الـ fg blur خفيف |
| Worm's-eye | عظمة مبالغ فيها، عالم الأطفال | أرضية، حذاء، سماء |

---

## 2. جدول emotion → shot + angle + lens + movement

| الإحساس | Size | Angle | Lens (full-frame) | Movement |
|---|---|---|---|---|
| وحدة / ضياع | EWS-WS | High | 24-35mm | Locked-off، أو pull-out بطيء |
| قوة / هيبة | MS-CU | Low | 24-35mm | Slow push-in |
| حميمية / حب | CU | Eye-level | 85mm، f/1.8 | Handheld ناعم / breathing |
| توتر / قلق | CU-ECU | Dutch خفيف | 24-35mm قريب | Handheld nervous، creeping push |
| صدمة / اكتشاف | CU → WS | أي | 14-24mm | Whip pan / dolly zoom |
| ذكرى / نوستالجيا | MCU | Eye-level | 50-85mm + soft | Slow drift، shallow DOF |
| تهديد من بعيد | WS | Low خلف الشخصية | 135mm compressed | Locked-off، الخطر بيقرب لوحده |
| فرحة / طاقة | MS | Eye/Low | 24mm | Tracking سريع، orbit |
| حزن / استسلام | MS-WS | High خفيف | 50mm | Locked-off + سكون |
| غموض | MS | Back / OTS | 50-85mm | Slow dolly خلف الشخصية |
| فخامة (product) | ECU-CU | Low 15-30° | 85-100mm macro | Slow slider، orbit |
| مراقبة / paranoia | WS | High / through-object | 85-135mm | Locked-off + zoom بطيء |
| حيرة | MS | Dutch / POV | 35mm | Handheld wander |

---

## 3. Lens psychology

| البعد (FF) | الإحساس | تشويه / ضغط | الاستخدام |
|---|---|---|---|
| 14mm | عالم ضخم، دوخة، فانتازيا | تشويه حاد في الحواف | معمار، action، مشاعر مبالغ فيها |
| 24mm | سياق + قرب، "الصحفي" | تشويه واضح في الوجوه القريبة | vlog، مشي وكلام |
| 35mm | عين الإنسان الطبيعية تقريباً | خفيف | docu، drama، street |
| 50mm | محايد صادق | تقريباً صفر | حوار، portrait نصفي |
| 85mm | portrait مثالي، وجه مجمّل | ضغط لطيف، خلفية ناعمة | CU، حب، beauty |
| 135mm+ | عزل، voyeur، خلفية مضغوطة | ضغط شديد، المسافات تتلاصق | تهديد، ازدحام، قمر كبير |
| Anamorphic | cinematic، flares أفقية، bokeh بيضاوي | squeeze 1.33/2x | scope 2.39:1، إحساس فيلم |

### Depth of Field (DOF)
- **Shallow (f/1.4-2.8):** عزل الموضوع، حميمية، "ده المهم".
- **Deep (f/8-16):** سياق، كل حاجة مهمة، docu، landscape.
- **Rack focus:** نقل الانتباه من فرد لفرد = جملة سينمائية كاملة.
- DOF بيزيد كل ما: قربت الكاميرا من الموضوع، فتحت الفتحة، كبّرت الحساس/الـ focal.

### Compression vs Distortion
- **Tele (85+):** بيضغط الخلفية فتبان قريبة وكبيرة (حلو لقمر ضخم خلف شخص). مفيش distortion في الوجه.
- **Wide (≤24):** الحاجة القريبة بتتضخم والبعيدة بتصغر؛ الأنف يكبر في الـ CU. استخدمه عمداً للكوميديا أو القلق.

### معادلات الموبايل (تقريبية، 35mm equivalent)
| العدسة | المكافئ | ملاحظات |
|---|---|---|
| Ultra-wide 0.5x | 13-16mm | تشويه، ممتاز للـ POV والمعمار |
| Main 1x | 24-26mm | الأقوى في الضوء والجودة |
| Tele 2x (crop أو عدسة) | 48-52mm | أحسن للوجوه من 1x |
| Tele 3-5x | 70-120mm | portrait حقيقي لو عدسة مش crop |
| Portrait mode | محاكاة DOF | بيغلط في الشعر والحواف؛ الأفضل تفصل الخلفية بالمسافة |

نصايح: ابعد 2-3 متر وزوّم 2x للوجوه بدل ما تقرب بالـ 1x. اقفل AE/AF lock بالضغط المطوّل. صوّر 4K/30 أو 24 للشكل السينمائي، و shutter = 2× الـ fps (180° rule).

---

## 4. Composition أبعد من rule of thirds

- **Leading lines:** طريق، سكة، سور، ضل، كابلات؛ بتوجّه العين لنقطة الاهتمام. أقوى لما تتقابل في الموضوع.
- **Frame within frame:** باب، شباك، مراية، فتحة بين إيدين، عربية؛ بيحبس الشخصية (سجن) أو بيركّز.
- **Negative space:** مساحة فاضية كبيرة حوالين موضوع صغير = وحدة، تأمل، مكان لنص/عنوان. سيب "look room" قدام عين الشخص.
- **Symmetry (Wes Anderson / Kubrick one-point):** مركز تام + خطوط متقاطعة = نظام، صرامة، سريالية. اكسرها بعنصر واحد غلط = توتر.
- **Depth layers:** فيه **Foreground** (blur أو silhouette) + **Midground** (الموضوع) + **Background** (سياق/ضوء). لقطة من 3 طبقات بتبان 3D حتى بالموبايل.
- **Color blocking:** ألوان مسطحة كبيرة (حيط أصفر + جاكيت أزرق). حدّد 2-3 ألوان للمشهد بالكامل. اللون المضاد (complementary) للموضوع بيفصله.
- **Golden ratio / spiral / diagonal:** للعين المدرّبة؛ الـ diagonal بيدي طاقة، الـ horizontal هدوء، الـ vertical قوة.
- **Figure-ground:** شخص مقابل خلفية نظيفة تتقري فوراً (اختبار الـ squint: ضيّق عينك، لسه تشوف الموضوع؟).
- **Odd numbers & grouping:** 3 عناصر أطبع من 2 أو 4.
- **Edge discipline:** ما تقطعش المفاصل (ركبة، رقبة، كوع). ما تسيبش حاجة ملهاش لازمة بتلمس الحافة.

### الـ 9:16 العمودي (Reels/TikTok/Shorts)
- **Safe zones:** سيب ~12% من فوق وحوالي 20-25% من تحت (الـ caption/الأزرار)، وجانب يمين ~10% لأيقونات التفاعل. الوجه والنص في المنتصف الأعلى.
- العين بتروح للثلث الأعلى؛ حط العينين على ~⅓ من فوق.
- الطول هو البُعد القوي: استغل **vertical depth** (شخص بعيد فوق، حاجة قريبة تحت) وطول الجسم وطلعات السلالم وناطحات السحاب.
- الـ wide الأفقي بيموت في العمودي؛ بدله استخدم **layers**، أو اقلب ال framing (frame في frame رأسي: باب، مصعد، سلم).
- الحركة الرأسية (tilt, crane up, ascend) طبيعية للصيغة دي.
- أول 1-2 ثانية: صورة غريبة أو حركة، مش لوجو.
- اشتغل بالـ 4:5 أو 9:16 من الأول بدل ما تقص من 16:9.

---

## 5. Camera movement + الدافع

**القاعدة:** الحركة لازم يكون ليها motivation: معلومة، عاطفة، أو سرد. حركة من غير سبب = ملل أو دوخة.

| الحركة | تعمل إيه | الإحساس / الدافع |
|---|---|---|
| Locked-off (ثابتة) | الكاميرا ساكنة تماماً | سلطة، سكون، ستايل Ozu/Anderson؛ خلّي الحدث هو المتحرك |
| Push-in / dolly in | تقرب ببطء | تركيز، توتر، دخول رأس الشخصية |
| Pull-out / dolly out | تبعد | عزلة، كشف السياق، وداع |
| Truck / track (جنب) | موازية للحركة | متابعة، مرافقة، عرض بيئة |
| Tracking / follow | وراء/قدام الشخص | رحلة، مطاردة، ألفة؛ من قدام = مواجهة |
| Crane / jib up/down | ارتفاع | كشف، افتتاح/ختام، عظمة |
| Orbit / arc | دوران حول الموضوع | بطولة، رومانسية، "اللحظة الكبيرة"، product |
| Handheld | اهتزاز بشري | واقعية، توتر، حميمية (تحكّم فيه: breathing مش زلزال) |
| Whip pan | لفة سريعة + blur | انتقال طاقة، مفاجأة، match cut مخفي |
| Dolly zoom (Vertigo) | dolly in + zoom out (أو العكس) | إدراك مرعب، دوخة، صدمة نفسية |
| Snorricam | الكاميرا مربوطة على الجسم | انفصال، سكر، ذعر؛ الخلفية بتتحرك والوجه ثابت |
| Whip tilt / crash zoom | حركة سريعة جداً | كوميديا، صدمة |
| Rack focus | تحويل الفوكاس | تحويل الانتباه من غير قطع |
| Parallax slide | slider جانبي مع fg | عمق 3D |
| Gimbal float | انسياب | حلم، فخامة؛ ماتبالغش |

نصايح تنفيذ: 
- بالموبايل: **mm** بالجيمبال + 3 نقاط (mode follow). للـ handheld اقعد على ركبتك وامسك بالكوعين على الجسم.
- **Dolly zoom** بالموبايل: امشي لقدام وانت بتعمل zoom out تدريجي (أو بالمونتاج: scale-in + warp). في Blender: حرّك الكاميرا و keyframe للـ focal length عكسياً.
- ثبّت السرعة: ease in/out بيدي إحساس احترافي.

---

## 6. Lighting

### Key / Fill / Back
- **Key:** الضوء الأساسي (اتجاه + جودة).
- **Fill:** بيرفع الضلال (reflector أو ضوء ضعيف).
- **Back / Rim / Hair:** بيفصل الشخص عن الخلفية، حدود مضيئة.
- **Kicker/Background light:** عمق في الخلفية.

### Ratios (key:fill)
| Ratio | الإحساس |
|---|---|
| 1:1 | مسطح، كوميدي، beauty/commercial |
| 2:1 | طبيعي ناعم، drama خفيف |
| 4:1 | درامي واضح |
| 8:1+ | noir، low-key، خطر |

### أنماط البورتريه
| النمط | الشكل | الدلالة |
|---|---|---|
| Butterfly / Paramount | ضوء فوق وأمام، ضل تحت الأنف | glamour، كلاسيك |
| Loop | ضوء 30-45° ضل أنف صغير على الخد | الأكثر تملقاً، عام |
| Rembrandt | مثلث ضوء على الخد المظلم | كلاسيكي، عمق، حزن نبيل |
| Split | نص الوجه ضوء ونص ضل | ازدواجية، شر، صراع داخلي |
| Rim / edge | حدود بس | غموض، فخامة |
| Under-lighting | من تحت | رعب، شر (استخدمه بحذر) |
| Broad vs Short | الجانب العريض/الضيق من الوجه للضوء | Short بيضيّق الوجه ويعطي حجم |

### مفاهيم
- **Motivated light:** الضوء يبدو جاي من مصدر منطقي في المشهد (شباك، لمبة، تلفزيون) حتى لو من spotlight مخفي.
- **Practicals:** مصادر ظاهرة في الكادر (أباجورة، نيون، شاشة) وهي بتضيء المشهد فعلاً.
- **Silhouette:** إضاءة الخلفية فقط، الشخص ظلام = غموض، شكل، شعر. اعمل exposure على الخلفية.
- **Chiaroscuro:** تباين حاد نور/ظلمة (Caravaggio)؛ الضلام هو نص اللوحة.
- **Hard vs Soft:** المصدر الصغير/البعيد = hard (ضلال حادة، درامي، شمس الظهر). المصدر الكبير/القريب = soft (ناعم، beauty). **الحجم النسبي للمصدر مقابل الموضوع هو اللي بيحدد**.
- **Inverse-square:** الضوء بيقل مع مربع المسافة؛ قرّب المصدر خطوة = فرق كبير.
- **Gobo / cookie:** ظل بنمط (ورق شجر، ستاير، شبابيك) = texture ودراما.
- **Volumetric / haze:** دخان خفيف أو بخار + ضوء من الجنب = أشعة مرئية.

### Color temperature وتباين الألوان
- Tungsten ≈ 3200K (برتقالي)، شمس ≈ 5600K، ضل/سما ≈ 7000K+ (أزرق).
- **Teal & Orange:** البشرة برتقالية، الضلال والخلفية teal؛ شغال لأنه complementary وبيفصل الوجه. ما تبالغش.
- **غيره:** 
  - Magenta/Cyan (cyberpunk، نيون).
  - Amber/Blue (غروب + ليل).
  - Green/Magenta (مرض، سينما فنية، Matrix).
  - Monochrome + لون واحد صارخ (أحمر على أسود).
  - Warm interior vs cool exterior: الأمان جوه والخطر برا.
- افتح white balance **يدوي** (مثلاً 4300K) وسيب اللمبات المختلطة تعمل تباين متعمّد، بدل ما تحاول توحدها.

---

## 7. إضاءة رخيصة بالموبايل (من البيت)

| المشكلة / الهدف | الحل |
|---|---|
| Key ناعم | شباك + ستارة بيضا أو ملاية رقيقة؛ اقعد 45° للشباك |
| Fill | ورق ألومنيوم على كرتونة، ملاية بيضا، حيط أبيض، فوم بورد |
| Back/Rim | لمبة LED مكتب، كشاف موبايل ثاني من وراء الكتف |
| Hard key درامي | كشاف الموبايل/لمبة LED من غير diffuser، من الجنب |
| Diffuser | ورق زبدة، فوط ورق، قماشة بيضا، ستيكر أبيض على الكشاف |
| Gobo | مروحة ورق، غربال، خرم في كرتونة، ستارة دانتيل، أوراق شجر |
| Color gel | ورق سلوفان ملون، شاشة تلفزيون/تابلت بلون، كوب بلاستيك ملون |
| Practicals | سلسلة LED، أباجورة، نيون USB، شمعة، شاشة لاب توب |
| Haze | بخار مياه سخنة، دخان بخور خفيف (تهوية!)، رشة مياه |
| Window light مسيطر | اقفل نصف الستارة، اقعد جنب الشباك، افصل عن الخلفية المظلمة |

سيناريوهات جاهزة:
1. **Rembrandt بيتي:** شباك على 45° يمين وفوق عين الشخص + كرتونة بيضا بعيدة شمال (أو من غير fill).
2. **Beauty ناعم:** شباك أمام الوجه + reflector أبيض تحت الذقن (butterfly-ish).
3. **Silhouette:** الشخص قدام شباك الغروب، expose على السما بـ -1 EV.
4. **Neon cyber:** لمبتين RGB (أو شاشة موبايل أحمر + أزرق) من الجنبين + خلفية مظلمة.
5. **Product glow:** منتج على ورقة بيضا مقوسة (sweep) + شباك جنب + كرتونة بيضا fill.

نصايح: استبعد لمبات السقف المصفرة لو معاك ضوء تاني، أو اتحكم فيها كـ practical. ما تخلطش 3 درجات لون من غير قصد. صوّر بـ ProRes/Log/HDR ON حسب الموبايل؛ لو مش واثق اقفل HDR وكوّن exposure يدوي (-0.3 للأمان).

---

## 8. Photography quick guide

### Exposure triangle
| العنصر | بيتحكم في | التبادل |
|---|---|---|
| Aperture (f) | كمية الضوء + DOF | f صغير = ضوء أكتر + خلفية blur |
| Shutter | الضوء + حركة | سريع يجمّد، بطيء يعمل blur |
| ISO | حساسية | عالي = noise |

مرجع سريع:
- حركة ناس: ≥1/250. رياضة: 1/1000. Handheld: ≥ 1/(focal length). 
- Portrait: f/1.8-2.8، ISO 100-400.
- Landscape: f/8-11، ISO 100، تربود.
- Sunny 16: شمس = f/16 و 1/ISO.
- استعمل exposure compensation: ثلج/سما +1، مشهد غامق -0.7.

### Golden hour / blue hour
- **Golden hour:** أول ساعة بعد الشروق وآخر ساعة قبل الغروب. ضوء ناعم دافي جانبي، بشرة ذهبية. الـ backlit + flare = حلم.
- **Blue hour:** 20-40 دقيقة قبل الشروق/بعد الغروب. ألوان باردة + أنوار المدينة؛ ممتاز للمدن ومصر القاهرة ليلاً.
- **Magic trick:** ضوء الظهر قاسي؛ استخدم الضل المفتوح أو اطلب سقف/شجرة.

### Long exposure
- تربود + ND filter (أو ND عن طريق تطبيق Live/Long exposure للموبايل).
- مياه حريرية: 0.5-2 ثانية. سحاب: 30 ث+. ضوء سيارات: 5-15 ث.
- **Light painting:** غرفة مظلمة + كشاف حركة.
- Stars: 20-25 ث، f/2.8، ISO 1600-3200، wide (قاعدة 500/focal).

### Portrait
- العين الأقرب للكاميرا هي الفوكاس.
- Catchlight في العين = حياة (شباك، لمبة).
- اطلب منه يبص قريب من العدسة مش في الشاشة. 
- Angle طفيف من فوق بيشيل الذقن المزدوجة، و low بيدي قوة.
- خلفية نظيفة + مسافة 2-3 م بين الشخص والخلفية = bokeh.
- اتكلم مع الموديل، ولقط لحظة بين البوزات.

### Product
- خلفية sweep نظيفة أو سطح ببن/فاكهة/خامة تعبّر عن المنتج.
- Soft key كبير + edge/rim لفصل الحواف (خصوصاً زجاج/معدن).
- المنعكسات: استخدم **flags** سودا لتحديد الحواف وبياض للتعبئة.
- Hero angle: ~15-30° من تحت إلى مستوى العين، 85-100mm أو 2x.
- Splashes / تفاصيل: ضوء من وراء للسوائل (backlight).
- نضّف المنتج! 80% من المشاكل بصمات وتراب.

---

## 9. Blender equivalents

| سينما | Blender (Cycles/EEVEE) |
|---|---|
| Focal length | `cam.data.lens` (mm) و `sensor_width` (36 = full-frame) |
| f-stop / DOF | `cam.data.dof.use_dof = True`, `aperture_fstop`, `focus_object` أو `focus_distance` |
| Anamorphic bokeh | `dof.aperture_ratio` (مثلاً 2.0)، `aperture_blades` |
| Soft key | Area light كبير وقريب (size كبير) |
| Hard key | Spot/Sun أو Area صغير (size 0.1-0.3 م) |
| Volumetrics | World/Scene volume (Principled Volume) + Spot/Area مرئي؛ Cycles أدق |
| Shutter / motion blur | `scene.render.use_motion_blur` + `motion_blur_shutter` 0.5 |
| ISO / exposure | `scene.view_settings.exposure` أو Filmic/AgX look |
| Color temp | Blackbody node على Color الضوء |
| Aspect 9:16 | `render.resolution_x=1080, resolution_y=1920` |
| Dolly zoom | keyframe على `location` + `lens` عكسياً |

```python
import bpy, math
from mathutils import Vector

scene = bpy.context.scene
scene.render.resolution_x, scene.render.resolution_y = 1080, 1920   # 9:16

# Subject (target)
bpy.ops.mesh.primitive_monkey_add(location=(0, 0, 1))
subj = bpy.context.active_object

# Camera + DOF
cam_data = bpy.data.cameras.new("Cam")
cam_data.lens = 85                       # portrait look
cam_data.sensor_width = 36
cam_data.dof.use_dof = True
cam_data.dof.focus_object = subj
cam_data.dof.aperture_fstop = 1.8
cam = bpy.data.objects.new("Cam", cam_data)
scene.collection.objects.link(cam)
cam.location = (0, -6, 1.2)
con = cam.constraints.new('TRACK_TO')
con.target, con.track_axis, con.up_axis = subj, 'TRACK_NEGATIVE_Z', 'UP_Y'
scene.camera = cam

def area(name, loc, energy, size, color=(1, 1, 1)):
    d = bpy.data.lights.new(name, 'AREA')
    d.energy, d.size, d.color = energy, size, color
    o = bpy.data.objects.new(name, d)
    scene.collection.objects.link(o)
    o.location = loc
    c = o.constraints.new('TRACK_TO')
    c.target, c.track_axis, c.up_axis = subj, 'TRACK_NEGATIVE_Z', 'UP_Y'
    return o

area("Key",  (-3, -3, 3),  800, 3.0, (1.0, 0.85, 0.7))   # warm, soft
area("Fill", ( 3, -3, 1),  150, 4.0, (0.7, 0.8, 1.0))    # cool, weak (~4:1)
area("Back", ( 0,  3, 3),  500, 1.0, (0.6, 0.8, 1.0))    # rim
```

ملاحظات: اختبر بـ `render.engine = 'BLENDER_EEVEE'` (الاسم الفعلي ممكن يختلف حسب نسخة 5.x؛ اتحقق من `bpy.types.RenderSettings.bl_rna.properties['engine'].enum_items`). شغّل headless: `blender -b scene.blend -P script.py -f 1`. للـ volumetric: أضف Cube كبير بـ Principled Volume density 0.02 واستخدم Spot من الجنب.

---

## 10. عشرين فكرة لقطة مبتكرة للـ Reels

1. **Mirror reveal:** كاميرا على مراية، الشخص "بيدخل" الكادر من انعكاسه؛ أو المراية بتبين حقيقة مختلفة.
2. **Shadow-only performance:** الأداء كله ظل على حيط بضوء hard؛ الشخص خارج الكادر.
3. **Through-object:** تصوير من خلال كوباية ميه، زجاجة، بروزم، سلك شبك، ورق سلوفان.
4. **Rotating world:** الكاميرا بتلف 360° على محور اللفة والشخص ثابت بالنسبة لها (roll)؛ العالم هو اللي بيلف.
5. **Macro-to-wide:** ECU عين/ذرّة سكر → pull-out لسه متصل لعالم كامل (بـ match cut أو zoom حقيقي).
6. **Hidden-cut one-take:** لقطة واحدة وهمية بتتقطع عند whip pan أو عبور عنصر أسود (باب، ضهر شخص).
7. **Match cut بالحركة:** مروحة → عجلة، قمر → لمبة، إيد بتفتح باب → إيد بتفتح كتاب.
8. **Reverse reveal:** الفيديو يتشغل بالعكس (قهوة تتجمع في الكوباية)، أو الجملة المتكلمة بالعكس.
9. **Foreground silhouette peel:** شجرة/عامود/إيد في fg بتعدي وتكشف الموضوع (wipe طبيعي).
10. **Split-frame diptych:** نص الكادر زمنين/مكانين، شخص بيمشي بينهم.
11. **Phone-as-window:** تصوير شاشة موبايل تعرض شيء، وبعدها push-in للشاشة ويندمج مع الحقيقة.
12. **Light-switch transition:** ضلام ثم ضوء يكشف مكان جديد (أو شخصية بملابس مختلفة).
13. **Reflection-only world:** المشهد بالكامل في بقعة مياه/خلفية سيارة/نظارة.
14. **Impossible gravity:** كاميرا مقلوبة (roll 180) والشخص يمشي على السقف؛ حركة بتأثير بسيط.
15. **Fingertip frame:** إيد المصوّر بتعمل frame وتغيّر الكادر (مثلث، عين) وبتصنع انتقال.
16. **Slit-scan / light trails:** shutter بطيء + حركة = أضواء ممطوطة تحولها لانتقال.
17. **Forced perspective:** شخص "ماسك" الشمس/برج/سيارة بتلاعب المسافات.
18. **Freeze-and-walk:** كل الناس ثابتين (بوز تثبيت) والبطل بس بيتحرك بالكادر (بدون مونتاج: اطلب منهم يتجمدوا).
19. **Object POV:** الكاميرا مربوطة بكوباية/كورة/موبايل رايح جاي (action cam على حاجة).
20. **Sound-visual pun:** كل beat صوتي له تغيير بصري (اللون، الزاوية، الزوم)؛ التصوير مصمم على الإيقاع قبل المونتاج.

> لو ناوي تولّد اللقطة بنموذج AI: اذكر الـ size + angle + lens + movement + lighting صراحة في البرومبت (مثلاً: "low angle, 24mm, slow push-in, Rembrandt key from window left, teal shadows, shallow DOF, 9:16").

---

## 11. Shot list template

| # | Scene/Beat | Size | Angle | Lens | Movement | Lighting | الدافع (Why) | Audio/Beat | Duration | Notes/Props |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | Hook | ECU | Eye | 85mm | Locked | Rim only | سؤال بصري | Riser | 1.5s | عين + انعكاس |
| 2 | | | | | | | | | | |
| 3 | | | | | | | | | | |
| 4 | | | | | | | | | | |
| 5 | Payoff | WS | High | 24mm | Pull-out | Practical | كشف + عزلة | Drop | 3s | |

حقول إضافية مفيدة: **Location, Talent, Gear (gimbal/tripod), Aspect (9:16/16:9), Backup shot, Time of day, Status (shot/ok/reshoot)**.
قاعدة: صوّر **Master + Medium + CU + Insert + Cutaway** لكل مشهد عشان المونتاج. وصوّر 3 ثواني زيادة قبل وبعد.

---

## 12. Critique checklist (10 أسئلة)

1. **الهدف:** اللقطة بتقول إيه في جملة واحدة؟ لو مفيش، احذفها.
2. **الموضوع:** مين/إيه اللي العين بتروح له أول ثانية؟ (squint test)
3. **الحجم والزاوية:** هل الـ size + angle مناسبين للإحساس؟ (راجع جدول القسم 2)
4. **العدسة والـ DOF:** هل الـ focal/الفتحة بتخدم العزل أو السياق؟ فيه تشويه غير مقصود؟
5. **التكوين:** فيه طبقات (fg/mg/bg)؟ خطوط توجيه؟ حواف نظيفة؟ negative space؟
6. **الإضاءة:** اتجاه وجودة وratio منطقيين؟ فيه motivated source؟ العينين فيها catchlight؟
7. **اللون:** palette من 2-3 ألوان؟ فصل الموضوع عن الخلفية؟ white balance متعمد؟
8. **الحركة:** لها دافع؟ ease in/out؟ ثابتة ولا فيها اهتزاز مش مقصود؟
9. **الصيغة:** 9:16 safe zones محترمة؟ أول ثانيتين فيهم hook؟ النص مقروء؟
10. **التميز:** لو شيلت اللقطة وحطيت لقطة stock، هل الفيديو هيفرق؟ لو لأ، اللقطة دي محتاجة فكرة (القسم 10).

> بعد النقد: عدّل **متغير واحد** في المرة (الزاوية أو الضوء أو الحركة) وقارن، بدل ما تغيّر كل حاجة وما تعرفش إيه اللي نفع.
