# Source integration — v1.3 and v1.2

Imported v1.3 implementation and regression tests where absent in v10.0.0. Original v1.2 archives and v1.3 remain unchanged. No font binary, user video, paid media or proprietary book is bundled.

The v1.2 archives were also compared by path and SHA256; source-v1.3 supersedes their older implementations in the affected modules. The v10.0 modules for catalog audit, 7-stage gate, cognition, Kling text planner, source links and permission-safe setup remain authoritative.

Imported paths: 
- `app/engines/audio.py`
- `app/engines/deliver.py`
- `app/engines/songs.py`
- `app/engines/montage.py`
- `app/engines/media.py`
- `app/engines/shadow_theatre/__init__.py`
- `app/engines/talking_head/render.py`
- `app/engines/dragon_montage/think.py`
- `app/engines/dragon_montage/pipeline.py`
- `app/engines/dragon_montage/storyboard.py`
- `app/engines/dragon_montage/direct.py`
- `app/engines/dragon_montage/mimic.py`
- `app/engines/dragon_montage/stock.py`
- `app/engines/dragon_montage/generate.py`
- `app/engines/dragon_montage/render.py`
- `app/engines/dragon_montage/common.py`
- `app/engines/dragon_montage/__main__.py`
- `app/engines/dragon_montage/taste.py`
- `app/engines/kling_director/__init__.py`
- `app/engines/kling_director/__main__.py`
- `app/engines/render/render.cjs`
- `app/engines/web_film/page.py`
- `app/engines/web_film/render.py`
- `app/engines/web_film/__main__.py`
- `app/engines/matrices/scene.py`
- `app/engines/cards/lib/photo_video_footage.py`
- `app/engines/cards/lib/fam_music_beat_sound.py`
- `app/engines/cards/lib/fam_transitions_cuts_b.py`
- `app/engines/cards/lib/fam_transitions_cuts_a.py`
- `app/engines/cards/lib/formats_platforms.py`
- `app/engines/cards/lib/fam_w3_05.py`
- `app/engines/cards/lib/fam_w3_09.py`
- `app/engines/cards/lib/fam_w3_06.py`
- `app/engines/cards/lib/core.py`
- `app/engines/cinema/assets/engine.js`
- `app/engines/dragon_montage/data/editor_mind.json`
- `tools/stock/free_photos.py`
- `tools/styles/build_style.py`
- `tools/styles/README.md`
- `tools/styles/common.js`
- `tools/styles/styles/chapters.js`
- `tools/styles/examples/chapters.json`
- `tools/styles/examples/clean.json`
- `tools/cartoon/tools/finish.sh`
- `tools/cartoon/tools/setup.sh`
- `tools/cartoon/tools/mix.py`
- `app/dragon/verify.py`
- `app/tests/test_v13_stock.py`
- `app/tests/test_v13_gate.py`
- `app/tests/test_v13_montage.py`
- `app/tests/test_v12_exact_length.py`
- `references/FREE_STOCK.md`
- `references/AUDIO_SONGS_QURAN.md`
- `references/MONTAGE_CONTRACTS.md`
- `references/STYLE_RECIPES.md`
- `references/QA.md`
- `references/LESSONS.md`
- `references/EXTERNAL_SKILLS.md`
