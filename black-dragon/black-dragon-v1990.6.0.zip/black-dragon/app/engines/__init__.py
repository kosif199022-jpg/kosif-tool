"""Specialised engines of the Black Dragon: media helpers, audio, montage (and later render, cinema)."""
