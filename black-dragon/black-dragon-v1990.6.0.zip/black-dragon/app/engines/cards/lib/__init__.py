"""Helper packs for data cards (written by tools/extract_cards.py --write-lib)."""
