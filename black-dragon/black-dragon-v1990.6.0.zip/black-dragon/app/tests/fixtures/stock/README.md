Saved, synthetic API answers for `test_v13_stock.py` (the shape of images-api.nasa.gov search/asset/metadata
responses, with made-up ids). The tests serve them through a fake transport: nothing leaves the machine.
